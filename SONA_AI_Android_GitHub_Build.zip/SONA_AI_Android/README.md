# SONA AI Android wrapper

This Android app opens the existing SONA AI Base44 website in a WebView.

## Build on GitHub using your phone

1. Create a new **public or private** GitHub repository named `SONA-AI-Android`.
2. Extract this ZIP on your phone.
3. Upload the **contents** of this folder to the repository root (make sure `.github/workflows/build-apk.yml` is included).
4. Open the repository on GitHub → **Actions** → **Build SONA AI APK** → **Run workflow**.
5. When the run finishes, open it and download the `SONA-AI-debug-APK` artifact.
6. Extract the downloaded artifact ZIP; install `app-debug.apk` on your Android phone.

## Notes
- This is a WebView wrapper, not a fully native assistant. It needs internet to load the Base44 website.
- Microphone permission is requested when the website asks for audio capture. Voice features still depend on Base44/browser compatibility and the website's own implementation.
- This is a debug APK for testing. A release APK should be signed before distribution.
- Do not put API keys or passwords in this repository.
